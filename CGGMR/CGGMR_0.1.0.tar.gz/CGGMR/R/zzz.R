.onUnload <- function (libpath) {
    library.dynam.unload("CGGMR", libpath)
}
