

#ifndef _myexport_RCPP_fJGGL_H
#define _myexport_RCPP_fJGGL_H

#include <RcppEigen.h>
#include <R.h>
#include <Rinternals.h>


//#define EIGEN_NO_DEBUG

													 
RcppExport	SEXP R_matrix_inverse(SEXP R_A); 
RcppExport	SEXP R_matrix_crossproduct_single(SEXP R_x);
RcppExport	SEXP R_matrix_tcrossproduct_single(SEXP R_x); 
RcppExport	SEXP R_eigen_decom(SEXP R_A); 
RcppExport	SEXP R_eigen_decom2(SEXP R_A); 	
RcppExport  SEXP R_xytx(SEXP R_x,SEXP R_y);
RcppExport  SEXP R_xy(SEXP R_x,SEXP R_y);							 
RcppExport  SEXP R_xty(SEXP R_x,SEXP R_y);							 
RcppExport  SEXP R_txy(SEXP R_x,SEXP R_y);
RcppExport  SEXP R_xyz(SEXP R_x,SEXP R_y,SEXP R_z);
RcppExport  SEXP R_xytz(SEXP R_x,SEXP R_y,SEXP R_z);
RcppExport  SEXP R_txyz(SEXP R_x,SEXP R_y,SEXP R_z);
RcppExport  SEXP R_txy(SEXP R_x,SEXP R_y);
RcppExport  SEXP R_xtx(SEXP R_x);
RcppExport  SEXP R_txx(SEXP R_x);	
RcppExport  SEXP R_elemwisexy(SEXP R_x,SEXP R_y);

					 
#endif

	

