#include <RcppArmadillo.h>


void find_fusions(arma::mat& M, const arma::mat& UWU, arma::sp_mat& U, double fuse_threshold);
