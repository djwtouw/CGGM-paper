
penalty.as.matrix=
function (lambda, p, penalize.diagonal) 
{
    if (is.matrix(lambda)) {
        if (sum(lambda != t(lambda)) > 0) {
            stop("error: penalty matrix is not symmetric")
        }
        if (sum(abs(dim(lambda) - p)) != 0) {
            stop("error: penalty matrix has wrong dimension")
        }
    }
    if (length(lambda) == 1) {
        lambda = matrix(lambda, p, p)
    }
    if (!penalize.diagonal) {
        diag(lambda) = 0
    }
    return(lambda)
}



soft	=
function(a,lam)
{ sign(a)*pmax(0, abs(a)-lam)}


