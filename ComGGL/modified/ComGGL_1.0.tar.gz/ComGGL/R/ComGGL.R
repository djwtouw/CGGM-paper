ComGGL=function(train,lambda1,lambda2,lambda3=1,K=NULL,pd=TRUE,
list.controls=list(penalize.diagonal=FALSE,plotConvergence=FALSE,seedKMEANS=1234,
rho=1,maxiterADMM=500,maxiterKMEANS=500,tol=1e-04,alpha=0.7))
{
    p = dim(train)[2]
    n = dim(train)[1]
    S = cov(train) * (n - 1)/n

	X 			= diag(1,p)
	Z1 			= diag(1,p)
	Z2 			= diag(1,p)
	U1 			= diag(1,p)
	U2 			= diag(1,p)
	Theta 		= diag(1,p)

	lam1 = penalty.as.matrix(lambda1, p, penalize.diagonal = list.controls$penalize.diagonal)
    colnames(lam1) = colnames(train)
    iter = 0
    DiffTargetObjective = 10
    Convergence = NULL
	DiffConvergence = NULL


TargetObjective_old		=0
TotalPenaltyTerm_old	=0
TotalThetaZ1diff_old 	=0
TotalXZ2diff_old 		=0


if (list.controls$plotConvergence==T){dev.new();par(mfrow=c(1,4))}

while ((iter == 0) || (iter < list.controls$maxiterADMM && DiffTargetObjective > list.controls$tol ))
{
A			= Z1
A[A!=0]		= 1

if(is.null(K)){
g3a 		= graph.adjacency(A, mode = "undirected", diag = T)
d			= igraph::degree(g3a)
if(sum(d)==0){rc=0}
if(sum(d)!=0){rc=sqrt(sum(d^2)/sum(d)-1)}
if(sum(d)!=0){rc=sqrt(mean(d))}
H			=(rc^2-1)*diag(1,p)-rc*A+diag(d,p)
edecomp		= .Call("R_eigen_decom2", R_A=(H),PACKAGE = "ComGGL")
myev=rev(edecomp$values)
last=length(myev)
kk=1
while (5*myev[last-kk+1]<=myev[last-kk] & kk<(length(myev)-1)){kk<-(kk+1)}
Components= kk-1
} else {Components  = K}



iter 		= iter+1

edecomp2	= .Call("R_eigen_decom2", R_A=(list.controls$rho*Z2-list.controls$rho*U2-lambda3*Theta),PACKAGE = "ComGGL")
Xtil2 		= (edecomp2$values)
Xtil22		= Xtil2
Q2 			= (edecomp2$vectors)
if(pd==TRUE){
Xtil2	 	= (Xtil2+sqrt(Xtil2^2 + 4*list.controls$rho))/(2*list.controls$rho)}
else {Xtil2[Xtil2<0]= 0}
X			= .Call("R_xytx", R_x=Q2,R_y=diag(Xtil2),PACKAGE = "ComGGL")[[1]]
Z2			= pmin(pmax(X+U2,0),matrix(1,p,p))
diag(Z2)=1
U2			= U2+(X-Z2)

edecomp	= .Call("R_eigen_decom2", R_A=(list.controls$rho*Z1-list.controls$rho*U1-S),PACKAGE = "ComGGL")
Xtil 		= (edecomp$values)
Q 			= (edecomp$vectors)
Xtil	 	= (Xtil+sqrt(Xtil^2 + 4*list.controls$rho))/(2*list.controls$rho)
Theta		= .Call("R_xytx", R_x=Q,R_y=diag(Xtil),PACKAGE = "ComGGL")[[1]]



if(Components>0){
myorder 	= order(abs(Xtil22),decreasing=T)[1:Components]
myX=Q2[,myorder]
# set.seed(list.controls$seedKMEANS)
q1=try(clus <- kmeans(myX, Components,iter.max = list.controls$maxiterKMEANS,nstart = Components), TRUE)
if (!inherits(q1, "try-error")) {
mycluster=clus$cluster
} else {mycluster=rep(1,p)}



bb 			= 0
for (k in 1:Components){
mywhich 	= which(mycluster==k)
bb=bb+sqrt(sum((Z1[mywhich,mywhich])^2))}
mynormsoft				= Z1*0+bb
myterm					= lambda2/mynormsoft
myterm[is.nan(myterm)]	= 0
myterm[myterm==Inf]		= 0
penalty 				= pmax(1-myterm,0)
Theta_hat 				= list.controls$alpha*Theta + (1 - list.controls$alpha)*Z1;
if(lambda2==0){Z1		= soft(Theta_hat+U1,lam1/list.controls$rho)}
if(lambda2!=0){Z1		= soft(Theta_hat+U1,lam1/list.controls$rho)*penalty}
U1						= U1+(Theta_hat-Z1)


ThetaX= .Call("R_xy", R_x=Theta,R_y=X,PACKAGE = "ComGGL")$XY
SThetaX= .Call("R_xy", R_x=S,R_y=ThetaX,PACKAGE = "ComGGL")$XY
STheta= .Call("R_xy", R_x=S,R_y=Theta,PACKAGE = "ComGGL")$XY

if(pd==TRUE){
TargetObjective= sum(diag(STheta))+lambda3*sum(diag(ThetaX))- sum(log(Xtil))-sum(log(Xtil2))+
						sum(abs(lambda1*Z1)) + lambda2*bb
} else {TargetObjective= sum(diag(STheta))+lambda3*sum(diag(ThetaX))- sum(log(Xtil))+
						sum(abs(lambda1*Z1)) + lambda2*bb}

}

if(Components==0){
Theta_hat 				= list.controls$alpha*Theta + (1 - list.controls$alpha)*Z1;
Z1						= soft(Theta_hat+U1,lam1/list.controls$rho)
U1						= U1+(Theta_hat-Z1)

ThetaX= .Call("R_xy", R_x=Theta,R_y=X,PACKAGE = "ComGGL")$XY
SThetaX= .Call("R_xy", R_x=S,R_y=ThetaX,PACKAGE = "ComGGL")$XY
STheta= .Call("R_xy", R_x=S,R_y=Theta,PACKAGE = "ComGGL")$XY

if(pd==TRUE){
TargetObjective= sum(diag(STheta))+lambda3*sum(diag(ThetaX))- sum(log(Xtil))-sum(log(Xtil2))+
						sum(abs(lambda1*Z1))
} else {TargetObjective= sum(diag(STheta))+lambda3*sum(diag(ThetaX))- sum(log(Xtil))+
						sum(abs(lambda1*Z1))}


}


# if(iter%%25==0){print(iter)}

DiffTargetObjective 	= abs(TargetObjective-TargetObjective_old)
TargetObjective_old	= TargetObjective

TotalPenaltyTerm		= sum(lam1*abs(Z1))*ifelse(Components>0,lambda2*bb,1)
DiffTotalPenaltyTerm 	= abs(TotalPenaltyTerm-TotalPenaltyTerm_old)
TotalPenaltyTerm_old	= TotalPenaltyTerm

TotalThetaZ1diff	=norm(Theta - Z1,"F")
DiffTotalThetaZ1diff 	= abs(TotalThetaZ1diff-TotalThetaZ1diff_old)
TotalThetaZ1diff_old	= TotalThetaZ1diff

TotalXZ2diff	=norm(X - Z2,"F")
DiffTotalXZ2diff 	= abs(TotalXZ2diff-TotalXZ2diff_old)
TotalXZ2diff_old	= TotalXZ2diff

Convergence	= rbind(Convergence,c(iter,TargetObjective,TotalPenaltyTerm,TotalThetaZ1diff,TotalXZ2diff,Components))
colnames(Convergence)=c("Iteration","TragetObjective","Penalty","(Theta-Z1)","(X-Z2)","NoClusters")

DiffConvergence	= rbind(DiffConvergence,c(iter,DiffTargetObjective,
DiffTotalPenaltyTerm,DiffTotalThetaZ1diff,DiffTotalXZ2diff))
colnames(DiffConvergence)=c("Iteration","DiffTargetObjective","DiffPenalty","Diff(Theta-Z1)","Diff(X-Z2)")

if (list.controls$plotConvergence==T){

par(mar=c(4, 5.5, 0, 0.5))
plot(x=Convergence[,1],y=Convergence[,2],type="l",ylab="ObjectiveFunction",yaxt="n",xlab="Iteration",
	xaxt="n",bty="n",ylim=c(0,500),cex.lab=2)
axis(1, seq(1,list.controls$maxiterADMM,by=50), cex.axis=1.6)
axis(2, seq(0,500, by=100), las=2, cex.axis=1.6)


par(mar=c(4, 5.5, 0, 0.5))
plot(x=Convergence[,1],y=Convergence[,4],type="l",ylab=expression(paste("||",Theta-tilde(Theta),"||")[F]),xlab="Iteration",col="brown",
cex.lab=2,yaxt="n", xaxt="n",bty="n",ylim=c(0,5))
legend("top",legend=round(tail(Convergence[,4],n=1),4),bty="n",cex=2)
axis(1, seq(1,list.controls$maxiterADMM,by=50), cex.axis=1.6)
axis(2, seq(0,5,by=1), las=2, cex.axis=1.6)
par(mar=c(4, 5.5, 0, 0.5))
plot(x=Convergence[,1],y=Convergence[,5],type="l",ylab=expression(paste("||",X-tilde(X),"||")[F]),xlab="Iteration",
col="brown",cex.lab=2,yaxt="n", xaxt="n",bty="n",ylim=c(0,5))
legend("top",legend=round(tail(Convergence[,5],n=1),4),bty="n",cex=2)
axis(1, seq(1,list.controls$maxiterADMM,by=50), cex.axis=1.6)
axis(2, seq(0,5,by=1), las=2, cex.axis=1.6)
par(mar=c(4, 5.5, 0, 0.5))
plot(x=Convergence[,1],y=Convergence[,6],type="l",ylab=expression(K[n]),xlab="Iteration",col="brown",cex.lab=2,yaxt="n", xaxt="n",bty="n",ylim=c(0,10))
legend("top",legend=round(tail(Convergence[,6],n=1),0),bty="n",cex=2)
axis(1, seq(1,list.controls$maxiterADMM,by=50), cex.axis=1.6)
axis(2, seq(0,10,by=1), las=2, cex.axis=1.6)

list.controls$rho = list.controls$rho*list.controls$rho.increment
}
}

# set.seed(list.controls$seedKMEANS)
q1=try(clus <- kmeans(myX, Components,iter.max = list.controls$maxiterKMEANS,nstart = Components), TRUE)
if (!inherits(q1, "try-error")) {mycluster=clus$cluster} else {mycluster=rep(1,p)}

colnames(A)=colnames(train)
colnames(X)=colnames(train)
colnames(Z1)=colnames(train)
colnames(Z2)=colnames(train)

rownames(A)=colnames(train)
rownames(X)=colnames(train)
rownames(Z1)=colnames(train)
rownames(Z2)=colnames(train)

return(list(Components=mycluster,A=A,X=X,Theta=Theta,Z1=Z1,Z2=Z2,Convergence=Convergence))
}
