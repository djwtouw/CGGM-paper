cvComGGL = function(Kfolds=3,
train,lambda1,lambda2,lambda3=1,K=NULL,pd=TRUE,
list.controls=list(penalize.diagonal=FALSE,plotConvergence=F,seedKMEANS=1234,
rho=1,maxiterADMM=500,maxiterKMEANS=500,tol=1e-04,alpha=0.7))
{

	lambda= expand.grid(lambda1,lambda2,lambda3)
	colnames(lambda)=c("Lambda1","Lambda2","Lambda3")
	lik_foldcv									= rep(0,nrow(lambda))
	trace_foldcv								= rep(0,nrow(lambda))
	
	for (j in 1:nrow(lambda)){
	print(paste("Lambda1-Lambda3 combination: ",j," out of ",nrow(lambda),sep=""))
		set.seed(4321+j)
		sam  									= sample(1:nrow(train))
		sam  									= split(sam, c(rep(1:Kfolds, each =ceiling(nrow(train)/Kfolds)),1)) 
		err1									= NULL
		err2									= NULL
			
		for(drop in 1:Kfolds){
			train2=train[-sam[[drop]],]
			concentration						= ComGGL(train2, lambda[j,1], lambda[j,2], lambda[j,3],K,pd,list.controls)$Z1
			err1								= c(err1,(-log(det(concentration))+sum(diag(concentration%*%cov(train[sam[[drop]],])))))
			err2								= c(err2,sum(diag((-diag(1,dim(concentration)[1])+ concentration%*%cov(train[sam[[drop]],]))^2)))
		}		
		lik_foldcv[j]							= mean(err1)	
		trace_foldcv[j]							= mean(err2)	
	
	}		
	optimal_lambda_lik							= lambda[which.min(lik_foldcv),]
	optimal_lambda_trace						= lambda[which.min(trace_foldcv),]
	
	
		all=cbind(lambda,lik_foldcv,trace_foldcv)
		colnames(all)=c("Lambda1","Lambda2","Lambda3","KfoldAverageLikLoss","KfoldAverageTrLoss")
		
	return(list(OptLamba_loglik=optimal_lambda_lik,OptLamba_tr=optimal_lambda_trace,Performance=all))
}

