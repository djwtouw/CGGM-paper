// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppEigen.h which pulls Rcpp.h in for us
#include <RcppEigen.h>
#include "linear_alg_exports.h"
#include <cstdlib>
#include <iostream>
#include <R.h>

using namespace Rcpp;
using namespace Eigen;
using namespace std;





 SEXP R_eigen_decom(SEXP R_A)
 {
	 NumericMatrix Rcpp_A(R_A);	
	 const int i1 = Rcpp_A.nrow(), j1 = Rcpp_A.ncol();
	 Map<MatrixXd> A(Rcpp_A.begin(), i1 ,j1);
    // AB =eigen_decom(A);
	
   const  EigenSolver<MatrixXd> es(A);
   return List::create(Named("L") = es.eigenvalues());
   }
   
  
  SEXP R_eigen_decom2(SEXP R_A)
 {
	 NumericMatrix Rcpp_A(R_A);	
	 const int i1 = Rcpp_A.nrow(), j1 = Rcpp_A.ncol();
	 Map<MatrixXd> A(Rcpp_A.begin(), i1 ,j1);
 //   AB =eigen_decom(A);
	
  const  SelfAdjointEigenSolver<MatrixXd> eigensolver(A);
  return List::create(Named("values") = eigensolver.eigenvalues(),
  Named("vectors") = eigensolver.eigenvectors());
  }
 
  SEXP R_xytx(SEXP R_x,SEXP R_y)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	MatrixXd op = x * y *x.transpose();
	return List::create(Named("AB") = op);       
}

  SEXP R_xy(SEXP R_x,SEXP R_y)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	MatrixXd op = x * y; 
	return List::create(Named("XY") = op);       
}



  SEXP R_xty(SEXP R_x,SEXP R_y)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	MatrixXd op = x * y.transpose(); 
	return List::create(Named("XtY") = op);       
}

  SEXP R_txy(SEXP R_x,SEXP R_y)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	MatrixXd op = x.transpose() * y; 
	return List::create(Named("tXY") = op);       
}
  SEXP R_xyz(SEXP R_x,SEXP R_y,SEXP R_z)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	NumericMatrix Rcpp_z(R_z);	
	 const int i3 = Rcpp_z.nrow(), j3 = Rcpp_y.ncol();
	 Map<MatrixXd> z(Rcpp_z.begin(), i3 ,j3); 
	 
	MatrixXd op = x * y * z;
	return List::create(Named("XYZ") = op);       
}
 
  SEXP R_xytz(SEXP R_x,SEXP R_y,SEXP R_z)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	NumericMatrix Rcpp_z(R_z);	
	 const int i3 = Rcpp_z.nrow(), j3 = Rcpp_y.ncol();
	 Map<MatrixXd> z(Rcpp_z.begin(), i3 ,j3); 
	 
	MatrixXd op = x * y * z.transpose();
	return List::create(Named("XYtZ") = op);       
}

  SEXP R_txyz(SEXP R_x,SEXP R_y,SEXP R_z)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	NumericMatrix Rcpp_z(R_z);	
	 const int i3 = Rcpp_z.nrow(), j3 = Rcpp_y.ncol();
	 Map<MatrixXd> z(Rcpp_z.begin(), i3 ,j3); 
	 
	MatrixXd op = x.transpose() * y * z;
	return List::create(Named("tXYZ") = op);       
}

  SEXP R_elemwisexy(SEXP R_x,SEXP R_y)
 {
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
 	NumericMatrix Rcpp_y(R_y);	
	 const int i2 = Rcpp_y.nrow(), j2 = Rcpp_y.ncol();
	 Map<MatrixXd> y(Rcpp_y.begin(), i2 ,j2); 
	
	MatrixXd op = x.cwiseProduct(y);
	return List::create(Named("elemwiseXY") = op);       
}



// t(A)*A
MatrixXd matrix_crossproduct_single(const MatrixXd& x)
{
	int n(x.cols());
	MatrixXd tAA(MatrixXd(n, n).setZero().selfadjointView<Lower>().rankUpdate(x.adjoint()));
	return(tAA);
}

SEXP R_txx(SEXP R_x) 
{
	 NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 

	MatrixXd	txx=matrix_crossproduct_single (x);
	return List::create(Named("tXX") = txx);       
}

// A*t(A)
MatrixXd matrix_tcrossproduct_single(const MatrixXd& x)
{
	int m(x.rows());
	MatrixXd AAt(MatrixXd(m, m).setZero().selfadjointView<Lower>().rankUpdate(x));
	return(AAt);
}

SEXP R_xtx(SEXP R_x)
{
	NumericMatrix Rcpp_x(R_x);	
	 const int i1 = Rcpp_x.nrow(), j1 = Rcpp_x.ncol();
	 Map<MatrixXd> x(Rcpp_x.begin(), i1 ,j1); 
 
	MatrixXd	xtx=matrix_tcrossproduct_single (x);
	return List::create(Named("XtX") = xtx);       
}

// A^{-1}
MatrixXd matrix_inverse(const MatrixXd& A)
{
	MatrixXd Ainv;
	Ainv			 		  = A.inverse();
	return(Ainv);
}

SEXP R_matrix_inverse(SEXP R_A) 
{
	NumericMatrix Rcpp_A(R_A);	
	const int i1 = Rcpp_A.nrow(), j1 = Rcpp_A.ncol();
	Map<MatrixXd> A(Rcpp_A.begin(), i1 ,j1);
	
	MatrixXd	Ainv=matrix_inverse(A);
	return List::create(Named("Ainv") = Ainv);       
}



Eigen::MatrixXd rcppeigen_hello_world() {
    Eigen::MatrixXd m1 = Eigen::MatrixXd::Identity(3, 3);
    Eigen::MatrixXd m2 = Eigen::MatrixXd::Random(3, 3);
	                     
    return m1 + 3 * (m1 + m2);
}


// another simple example: outer product of a vector, 
// returning a matrix
//
// [[Rcpp::export]]
Eigen::MatrixXd rcppeigen_outerproduct(const Eigen::VectorXd & x) {
    Eigen::MatrixXd m = x * x.transpose();
    return m;
}

// and the inner product returns a scalar
//
// [[Rcpp::export]]
double rcppeigen_innerproduct(const Eigen::VectorXd & x) {
    double v = x.transpose() * x;
    return v;
}

// and we can use Rcpp::List to return both at the same time
//
// [[Rcpp::export]]
Rcpp::List rcppeigen_bothproducts(const Eigen::VectorXd & x) {
    Eigen::MatrixXd op = x * x.transpose();
    double          ip = x.transpose() * x;
    return Rcpp::List::create(Rcpp::Named("outer")=op,
                              Rcpp::Named("inner")=ip);
}


